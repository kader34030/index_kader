
<?php
include "functions.php";

loginCheck(false);
outputPage(); ?>

